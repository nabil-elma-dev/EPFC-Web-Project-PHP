<?php
    require_once "functions.php";

    if(isset($_GET["pseudo"])){
        $pseudo = $_GET["pseudo"];
    }
    else{
        die("This page expects a `pseudo` parameter via the GET method");
    }
    try
    {
        $query = $pdo->prepare("SELECT * FROM Members WHERE pseudo = :pseudo");
        $query->execute(["pseudo" => $pseudo]);
        $profile = $query->fetch(); // un seul résultat au maximum
    }
    catch (Exception $exc)
    {
        die("Error while accessing database. Please contact your administrator.");
    }
    if($query->rowCount()==0){
        die("Can't find user '$pseudo' in the database.");
    }
    else{
        $description = $profile["profile"];
        $picture_path = $profile["picture_path"];
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <title><?= $pseudo ?>'s Profile!</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="styles.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="title"><?= $pseudo ?>'s Profile!</div>
        <div class="menu">
            <a href="profile.php?pseudo=<?= $pseudo ?>">Home</a>
            <a href="members.php">Members</a>
            <a href="friends.php">Friends</a>
            <a href="messages.php">Messages</a>
            <a href="edit_profile.php">Edit Profile</a>
            <a href="logout.php">Log Out</a>
        </div>
        <div class="main">
            <div>
                <?php
                if(mb_strlen($description ?? '') == 0){
                    echo 'No profile string entered yet!';
                } else {
                    echo $description;
                }
                ?>
            </div>
            <div>
                <?php
                if(mb_strlen($picture_path ?? '') == 0){
                    echo 'No picture loaded yet!';
                } else {
                    echo "<img src=\"$picture_path\" width=\"100\" alt=\"$pseudo&apos;s picture\">";
                }
                ?>
            </div>
        </div>
    </body>
</html>
