<?php
    require_once "functions.php";

    check_login();
    
    $profile = '';
    $picture_path = '';
    
    try{
        $query = $pdo->prepare("SELECT profile, picture_path FROM Members WHERE pseudo=:pseudo");
        $query->execute(["pseudo"=>$user]);
        $result = $query->fetch();
        $profile = $result['profile'];
        $picture_path = $result['picture_path'];
    } catch (Exception $ex) {
        die("Error while accessing database. Please contact your administrator.");
    }
    
    
    if(isset($_POST['profile'])){
        $profile = trim($_POST['profile']);       
        try{
            $query = $pdo->prepare("UPDATE Members SET profile=:profile WHERE pseudo=:pseudo ");
            $query->execute(["profile"=>$profile, "pseudo"=>$user]);
            $success = "Your profile has been successfully updated."; 
        } catch (Exception $ex) {
            die("Error while accessing database. Please contact your administrator.");
        }
    }

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Update Your Profile</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="styles.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="title">Update Your Profile</div>
        <div class="menu">
            <a href="profile.php">Home</a>
            <a href="members.php">Members</a>
            <a href="friends.php">Friends</a>
            <a href="messages.php">Messages</a>
            <a href="edit_profile.php">Edit Profile</a>
            <a href="logout.php">Log Out</a>
        </div>
        <div class="main">
            <form method="post" action="edit_profile.php" enctype="multipart/form-data">
                <h4>Enter or edit your details and/or upload an image.</h4>
                <textarea name="profile" cols="50" rows="3"><?= escape($profile) ?></textarea>

                Image: <input type="file" name="image" accept="image/x-png, image/gif, image/jpeg">
                <?php
                if(mb_strlen($picture_path ?? '') == 0){
                    echo 'No picture loaded yet!';
                } else {
                    echo "<img src=\"" . escape($picture_path) . "\" width=\"100\" alt=\"profile picture\">";
                }
                ?>

                <input type="submit" value="Save Profile">
            </form>
            <?php
            if(isset($success))
                echo "<div class=\"success\">$success</div>";
            if(isset($error))
                echo "<div class=\"errors\">" . escape($error) . "</div>";
            ?>
        </div>
    </body>
</html>
