<?php
    require_once("functions.php");
    
    $pseudo = '';
    $password = '';
    $password_confirm = '';
    
    if(isset($_POST['pseudo']) && isset($_POST['password']) && isset($_POST['password_confirm'])){
        $pseudo = trim($_POST['pseudo']);
        $password = trim($_POST['password']);
        $password_confirm = trim($_POST['password_confirm']);
        
        try{
            $query = $pdo->prepare("SELECT * FROM Members WHERE pseudo=:pseudo");
            $query->execute(["pseudo"=>$pseudo]);
            $result = $query->fetchAll();
            if(count($result)!=0)
                $errors[] = "This username is already taken";
        } catch (Exception $e){
            die("Error while accessing database. Please contact your administrator.");
        }
        
        if($pseudo == '')
            $errors[] = "Pseudo is required";
        if(mb_strlen($pseudo) < 3)
            $errors[] = "Pseudo must be at least 3 characters long";
        if($password != $password_confirm)
            $errors[] = "Passwords must match";
        
        if(!isset($errors)){
            try{
                $query = $pdo->prepare("INSERT INTO Members(pseudo, password)
                                        VALUES(:pseudo, :password)");
                $query->execute(["pseudo"=>$pseudo, "password"=>$password]);
                session_regenerate_id(true);
                $_SESSION["user"] = $pseudo;
                redirect("profile.php");
            } catch (Exception $ex) {
                die("Error while accessing database. Please contact your administrator.");
            }
        }
    }
?>


<!DOCTYPE html>
<html>
    <head>
        <title>Sign Up</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="styles.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="title">Sign Up</div>
        <div class="menu">
            <a href="index.php">Home</a>
        </div>
        <div class="main">
            <h4>Please enter your details to sign up:</h4>
            <form action="signup.php" method="post">
                <table>
                    <tr>
                        <td>Pseudo:</td>
                        <td><input id="pseudo" name="pseudo" type="text" value="<?= escape($pseudo) ?>"></td>
                    </tr>
                    <tr>
                        <td>Password:</td>
                        <td><input id="password" name="password" type="password" value="<?= escape($password) ?>"></td>
                    </tr>
                    <tr>
                        <td>Confirm Password:</td>
                        <td><input id="password_confirm" name="password_confirm" type="password" value="<?= escape($password_confirm) ?>"></td>
                    </tr>
                </table>
                <input type="submit" value="Sign Up">
            </form>
            <?php
                if (isset($errors)) {
                    echo "<div class=\"errors\">";
                    echo "<p>Please correct the following errors:</p>";
                    echo "<ul>";
                    foreach ($errors as $error) {
                        echo "<li>" . escape($error) . "</li>";
                    }
                    echo "</ul></div>";
                }
            ?>
        </div>
    </body>
</html>
