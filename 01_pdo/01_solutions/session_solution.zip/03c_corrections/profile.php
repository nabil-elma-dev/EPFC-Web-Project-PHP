<?php
    require_once "functions.php";

    check_login();

    if(isset($_GET["pseudo"])){
        $pseudo = trim($_GET["pseudo"]);
    }
    else
    {
        $pseudo = $user;
    }
    try
    {
        $query = $pdo->prepare("SELECT * FROM Members WHERE pseudo = :pseudo");
        $query->execute(["pseudo" => $pseudo]);
        $profile = $query->fetch(); // un seul résultat au maximum
    }
    catch (Exception $exc)
    {
        die("Error while accessing database. Please contact your administrator.");
    }
    if ($query->rowCount() == 0) {
        die("Can't find user '" . escape($pseudo) . "' in the database.");
    }
    else{
        $description = $profile["profile"];
        $picture_path = $profile["picture_path"];
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <title><?= escape($pseudo) ?>'s Profile!</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="styles.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="title"><?= escape($pseudo) ?>'s Profile!</div>
        <div class="menu">
            <a href="profile.php">Home</a>
            <a href="members.php">Members</a>
            <a href="friends.php">Friends</a>
            <a href="messages.php">Messages</a>
            <a href="edit_profile.php">Edit Profile</a>
            <a href="logout.php">Log Out</a>
        </div>
        <div class="main">
            <div>
                <?php
                if(mb_strlen($description ?? '') == 0){
                    echo 'No profile string entered yet!';
                } else {
                    echo escape($description);
                }
                ?>
            </div>
            <div>
                <?php
                if(mb_strlen($picture_path ?? '') == 0){
                    echo 'No picture loaded yet!';
                } else {
                    echo "<img src=\"" . escape($picture_path) . "\" width=\"100\" alt=\"" . escape($pseudo) . "&apos;s picture\">";
                }
                ?>
            </div>
        </div>
    </body>
</html>
